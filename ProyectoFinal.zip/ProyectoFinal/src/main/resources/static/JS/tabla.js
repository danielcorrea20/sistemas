$(document).ready(function() {
    cargarAlumnos();
});
async function cargarAlumnos(){
    const request = await fetch('/listar', {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
    });
    const alumnos = await request.json();

    let listadoHTML ='';
    for(let alumno of alumnos){
        let fila = '<tr>><td>'+alumno.id+'</td><td>'
            +alumno.nombre+'</td>'+'<td>'
        +alumno.nota+'</td><td><button onclick="eliminar('+alumno.id+')">Eliminar</button></td>'+'<td><button onclick="cambiarValor('+ +')">Editar</button></td></tr>';
        listadoHTML=listadoHTML+fila;
    }

    document.querySelector('#alumnos tbody').outerHTML=listadoHTML


}


async function add(id) {
    let datos1 ={};

    datos1.nombre = document.getElementById('txtalumno').value;
    datos1.nota = document.getElementById('txtnota').value;
    const request = await fetch('/añadir', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos1),
    });
    location.reload();

}
function cambiarValor(id){
    document.getElementById('idAlumno').value=id;
}
