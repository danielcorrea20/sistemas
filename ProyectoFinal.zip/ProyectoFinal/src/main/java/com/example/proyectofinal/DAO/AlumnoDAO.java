package com.example.proyectofinal.DAO;


import com.example.proyectofinal.Modelo.Alumno;

import java.util.List;

public interface AlumnoDAO {

    List<Alumno> listarAlumno();

    void delete(int id);

    void add(Alumno alumno);


}
