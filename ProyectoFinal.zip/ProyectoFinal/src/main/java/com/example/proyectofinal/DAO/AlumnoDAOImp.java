package com.example.proyectofinal.DAO;

import com.example.proyectofinal.Modelo.Alumno;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
@Transactional
public class AlumnoDAOImp implements AlumnoDAO {

    @PersistenceContext
    EntityManager entityManager;



    @Override
    public List<Alumno> listarAlumno() {
        String query = "FROM Alumno";
        return  entityManager.createQuery(query).getResultList();
    }

    @Override
    public void delete(int id){
        Alumno alumno = entityManager.find(Alumno.class,id);
        entityManager.remove(alumno);

    }

    @Override
    public void add(Alumno alumno){
       entityManager.merge(alumno);
    }


}


