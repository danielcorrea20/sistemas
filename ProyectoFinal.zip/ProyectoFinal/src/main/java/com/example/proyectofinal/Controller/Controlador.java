package com.example.proyectofinal.Controller;

import com.example.proyectofinal.DAO.AlumnoDAO;
import com.example.proyectofinal.Modelo.Alumno;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class Controlador {

    @Autowired
    AlumnoDAO alumnoDAO;
    @GetMapping("/listar")
    public List<Alumno>alumnos(){
        return  alumnoDAO.listarAlumno();
    }
    @DeleteMapping("/eliminar/{id}")
    public void delete(@PathVariable int id){
        alumnoDAO.delete(id);
    }

    @PostMapping("/añadir")
    public void add(@RequestBody Alumno alumno){
        alumnoDAO.add(alumno);
    }

    @PutMapping("/editar")
    public void edit(@PathVariable int id, @PathVariable int nota){
        alumnoDAO.edit(id, String.valueOf(nota));
    }

}
