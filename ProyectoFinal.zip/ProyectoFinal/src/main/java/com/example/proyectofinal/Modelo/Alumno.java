package com.example.proyectofinal.Modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@Table(name = "alumno")
@EqualsAndHashCode
@Entity
public class Alumno {
    @Id
    @Column(name = "id")
    private int id;
    @Column(name = "nombre")
    private String nombre;
    @Column(name = "contraseña")
    private String contraseña;
    @Column(name = "nota")
    private int nota;
    @Column(name = "codigo_id")
    private int codigo_id;


}
